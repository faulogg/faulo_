package mchorse.emoticons.skin_n_bones.api.metamorph.editor;

public interface IBonePicker
{
    public void pickBone(String bone);
}